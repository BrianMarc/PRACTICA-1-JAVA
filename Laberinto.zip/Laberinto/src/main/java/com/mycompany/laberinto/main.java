/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.laberinto;

import java.util.Scanner;

/**
 *
 * @author Brian Marconi
 */
public class main {

    public static final int TAMAÑO = 30;
    static int cantAtrapado = 0;
    static int cantPartidasGanadas = 0;
    static int cantPartidas = 0;
    static int totalORO = 0;
    static int vidas = 3;
    static int filaJ = 0;
    static int columnaJ = 0;
    static int filaB = 0;
    static int columnaB = 0;
    static boolean bandera = true;
    static boolean gameOver = true;
    static boolean turnoJ = true;
    static boolean turnoB = true;
    static int movimientosTotales = 0;
    static String direccion = "derecha";
    static char matriz[][] = new char[TAMAÑO][TAMAÑO];

    static Scanner sc1 = new Scanner(System.in);
    static Scanner sc2 = new Scanner(System.in);

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("\n>>>>>>ESCAPA DEL LABERITNO<<<<<<\n");
        int opcion = 0;

        do {

            System.out.println("******* Menu Principal *******");
            System.out.println("1. JUGAR");
            System.out.println("2. CREAR MAPA");
            System.out.println("3. REPORTES");
            System.out.println("4. VIZUALIZAR MAPA");
            System.out.println("5. SALIR");
            opcion = sc.nextInt();

            if (opcion == 1) {

                turnoJ = true;
                turnoB = true;
                gameOver = true;
                bandera = true;
                System.out.println("\tINSTRUCCIONES\n");
                System.out.println("Para interactuar en el juego debes de ingresar los comandos que se presentan a continuacion\n");
                System.out.println("COMANDO\t\tFUNCION\n");
                System.out.println("ORO REQUERIDO\tINDICA LA CANTIDAD DE ORO PARA SALIR EN LAS CASILLAS S");
                System.out.println("ORO\t\tINDICA LA CANTIDAD DE ORO QUE TIENES");
                System.out.println("LEVANTAR\tRECOGE CIERTA CANTIDAD DE ORO EN LAS CASILLAS G");
                System.out.println("MIRAR\t\tMUESTAR UN ACERCAMIENTO DEL MAPA");
                System.out.println("SALIR\t\tSALIR DEL LABERINTO TENIENDO SUFICINENTE ORO");

                System.out.println("\nSeleccione Mapa");
                System.out.println("1. Mapa por defecto");
                int opcMapa = sc.nextInt();
                if (opcMapa == 1) {

                    ubicarJugadores();

                    while (gameOver) {

                        do {
                            jugar(matriz, filaJ(matriz), columasJ(matriz));

                        } while (turnoJ);

                        if (gameOver == true) {
                            do {
                                Bot(matriz, filaB(matriz), columasB(matriz));
                            } while (turnoB);
                        }

                    }

                    System.out.println("\nTERMINA EL JUEGO\n");
                    System.out.println("******REPORTES******");
                    System.out.println("ORO RECOLECTADO: " + totalORO);
                    System.out.println("CANTIDAD DE MOVIMIENTOS: " + movimientosTotales);
                    System.out.println(" ");

                }

            }

            if (opcion == 2) {
                System.out.println("Error, esta opcion no esta disponible");
            }

            if (opcion == 3) {
                reportes();
            }

            if (opcion == 4) {
                visualizarMapa();
            }

            if (opcion == 5) {
                System.out.println("SALIENDO....");
            }
        } while (opcion != 5);

    }

//    
//    
//    
//    
//    
    //metodos
    public static void reportes() {
        System.out.println("----------REPORTES----------");
        System.out.println("-Cantidad de veces atrapado por el bot: " + cantAtrapado);
        System.out.println("-Cantidad de partidas ganadas: " + cantPartidasGanadas);
        System.out.println("-Promedio de oro por partida:  " + totalORO / cantPartidas);
        System.out.println("-Promedio de movimientos por partida: " + movimientosTotales / cantPartidas);
        System.out.println("ENTER PARA CONTINUAR");
        sc1.nextLine();
    }

    public static void visualizarMapa() {
        int map = 0;
        Scanner entradaMapa = new Scanner(System.in);
        System.out.println("----------LISTA DE MAPAS----------");
        System.out.println("1. MAPA POR DEFECTO");
        map = entradaMapa.nextInt();
        if (map == 1) {
            imprimiMatriz(mapaPorDefecto());
            System.out.println("ENTER PARA CONTINUAR");
            sc1.nextLine();
        }
    }

    public static int aleatorio(int inicial, int max) {
        return (int) (Math.random() * ((max - inicial) + 1)) + inicial;
    }

    public static void ubicarJugadores() {
        do {
            matriz = mapaPorDefecto();
            filaJ = aleatorio(0, TAMAÑO - 1);
            columnaJ = aleatorio(0, TAMAÑO - 1);
            filaB = aleatorio(0, TAMAÑO - 1);
            columnaB = aleatorio(0, TAMAÑO - 1);

            if (matriz[filaJ][columnaJ] == 'O' && matriz[filaB][columnaB] == 'O') {

                matriz[filaJ][columnaJ] = 'J';
                matriz[filaB][columnaB] = 'B';
                bandera = false;

            } else {
                filaJ = aleatorio(0, TAMAÑO - 1);
                columnaJ = aleatorio(0, TAMAÑO - 1);
                filaB = aleatorio(0, TAMAÑO - 1);
                columnaB = aleatorio(0, TAMAÑO - 1);

            }
        } while (bandera);

    }

    public static void jugar(char[][] matriz, int filas, int columnas) {

        do {

            System.out.println("\nIngrese el comando MOVER espacio e(derecha)- o(izquierda)- s(abajo)- n(arriva) para indicar la direccion del movimiento");
            System.out.println("O ingrese los comando antes mencionados, use bien los comandos o puede perder");
            System.out.println("SU TURNO");
            String comando = sc1.nextLine();;

            if (comando.equalsIgnoreCase("mover e")) {
                vidas = 3;
                if (matriz[filas][columnas + 1] != '#' && matriz[filas][columnas + 1] != '|' && matriz[filas][columnas + 1] != '-') {
                    matriz[filas][columnas + 1] = 'J';
                    matriz[filas][columnas] = 'O';
                    columnas++;
                    System.out.println("Se realizo el movimiento satisfactoriamente");
                    movimientosTotales++;
                    turnoJ = false;

                } else {
                    System.out.println("No se completo el movimiento casilla ocupada");
                    turnoJ = false;
                }
            } else if (comando.equalsIgnoreCase("mover o")) {
                vidas = 3;
                if (matriz[filas][columnas - 1] != '#' && matriz[filas][columnas - 1] != '|' && matriz[filas][columnas - 1] != '-') {
                    matriz[filas][columnas - 1] = 'J';
                    matriz[filas][columnas] = 'O';
                    columnas--;
                    System.out.println("Se realizo el movimiento satisfactoriamente");
                    movimientosTotales++;
                    turnoJ = false;

                } else {
                    System.out.println("No se completo el movimiento casilla ocupada");
                    turnoJ = false;
                }
            } else if (comando.equalsIgnoreCase("mover n")) {
                vidas = 3;
                if (matriz[filas - 1][columnas] != '#' && matriz[filas - 1][columnas] != '|' && matriz[filas - 1][columnas] != '-') {
                    matriz[filas - 1][columnas] = 'J';
                    matriz[filas][columnas] = 'O';
                    filas--;
                    System.out.println("Se realizo el movimiento satisfactoriamente");
                    movimientosTotales++;
                    turnoJ = false;

                } else {
                    System.out.println("No se completo el movimiento casilla ocupada");
                    turnoJ = false;
                }
            } else if (comando.equalsIgnoreCase("mover s")) {
                vidas = 3;
                if (matriz[filas + 1][columnas] != '#' && matriz[filas + 1][columnas] != '|' && matriz[filas + 1][columnas] != '-') {
                    matriz[filas + 1][columnas] = 'J';
                    matriz[filas][columnas] = 'O';
                    filas++;
                    System.out.println("Se realizo el movimiento satisfactoriamente");
                    movimientosTotales++;
                    turnoJ = false;
                } else {
                    System.out.println("No se completo el movimiento casilla ocupada");
                    turnoJ = false;
                }
//
//
            } else if (comando.equalsIgnoreCase("LEVANTAR")) {
                vidas = 3;

                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[6][2]) {
                    totalORO = totalORO + 3;
                    System.out.println("HA CONSEGUIDO 3 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }

                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[4][4]) {
                    totalORO = totalORO + 5;
                    System.out.println("HA CONSEGUIDO 5 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }

                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[4][9]) {
                    totalORO = totalORO + 7;
                    System.out.println("HA CONSEGUIDO 7 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[4][10]) {
                    totalORO = totalORO + 3;
                    System.out.println("HA CONSEGUIDO 3 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[12][4]) {
                    totalORO = totalORO + 1;
                    System.out.println("HA CONSEGUIDO 1 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[19][2]) {
                    totalORO = totalORO + 5;
                    System.out.println("HA CONSEGUIDO 5 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[20][2]) {
                    totalORO = totalORO + 7;
                    System.out.println("HA CONSEGUIDO 7 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[5][12]) {
                    totalORO = totalORO + 2;
                    System.out.println("HA CONSEGUIDO 2 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[5][12]) {
                    totalORO = totalORO + 2;
                    System.out.println("HA CONSEGUIDO 2 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[4][14]) {
                    totalORO = totalORO + 5;
                    System.out.println("HA CONSEGUIDO 5 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[29][7]) {
                    totalORO = totalORO + 8;
                    System.out.println("HA CONSEGUIDO 8 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[16][9]) {
                    totalORO = totalORO + 1;
                    System.out.println("HA CONSEGUIDO 1 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[25][9]) {
                    totalORO = totalORO + 3;
                    System.out.println("HA CONSEGUIDO 3 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[15][13]) {
                    totalORO = totalORO + 2;
                    System.out.println("HA CONSEGUIDO 2 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[24][13]) {
                    totalORO = totalORO + 3;
                    System.out.println("HA CONSEGUIDO 3 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[20][14]) {
                    totalORO = totalORO + 7;
                    System.out.println("HA CONSEGUIDO 7 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[11][20]) {
                    totalORO = totalORO + 2;
                    System.out.println("HA CONSEGUIDO 2 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[20][18]) {
                    totalORO = totalORO + 2;
                    System.out.println("HA CONSEGUIDO 2 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[26][18]) {
                    totalORO = totalORO + 9;
                    System.out.println("HA CONSEGUIDO 9 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[18][19]) {
                    totalORO = totalORO + 2;
                    System.out.println("HA CONSEGUIDO 2 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[20][22]) {
                    totalORO = totalORO + 3;
                    System.out.println("HA CONSEGUIDO 3 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[26][26]) {
                    totalORO = totalORO + 5;
                    System.out.println("HA CONSEGUIDO 5 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[10][27]) {
                    totalORO = totalORO + 1;
                    System.out.println("HA CONSEGUIDO 1 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[17][27]) {
                    totalORO = totalORO + 4;
                    System.out.println("HA CONSEGUIDO 4 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[8][29]) {
                    totalORO = totalORO + 7;
                    System.out.println("HA CONSEGUIDO 7 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[9][29]) {
                    totalORO = totalORO + 1;
                    System.out.println("HA CONSEGUIDO 1 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[29][29]) {
                    totalORO = totalORO + 10;
                    System.out.println("HA CONSEGUIDO 10 DE ORO");
                    System.out.println("ORO TOTAL: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE ORO");
                    turnoJ = false;
                    break;
                }
//                
//                

            } else if (comando.equalsIgnoreCase("ORO REQUERIDO")) {
                vidas = 3;
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[2][1]) {
                    System.out.println("\nOro requerido para salir de laberinto: 15");
                    System.out.println("Oro Disponible: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }

                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[1][9]) {
                    System.out.println("\nOro requerido para salir de laberinto: 30");
                    System.out.println("Oro Disponible: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[2][30]) {
                    System.out.println("\nOro requerido para salir de laberinto: 51");
                    System.out.println("Oro Disponible: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[22][30]) {
                    System.out.println("\nOro requerido para salir de laberinto: 55");
                    System.out.println("Oro Disponible: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[30][14]) {
                    System.out.println("\nOro requerido para salir de laberinto: 43");
                    System.out.println("Oro Disponible: " + totalORO);
                    System.out.println("enter para continuar");
                    sc1.nextLine();

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }
//                
//                

            } else if (comando.equalsIgnoreCase("SALIR")) {
                vidas = 3;
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[2][1]) {
                    if (totalORO >= 15) {
                        System.out.println("HAS GANADO !!!! ");
                        gameOver = false;
                        cantPartidasGanadas++;
                    } else {
                        System.out.println("No tienes suficiente oro, sigue recolectando");

                    }

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[1][9]) {
                    if (totalORO >= 30) {
                        System.out.println("HAS GANADO !!!! ");
                        gameOver = false;
                        cantPartidasGanadas++;
                    } else {
                        System.out.println("No tienes suficiente oro, sigue recolectando");

                    }

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[2][30]) {
                    if (totalORO >= 51) {
                        System.out.println("HAS GANADO !!!! ");
                        gameOver = false;
                        cantPartidasGanadas++;
                    } else {
                        System.out.println("No tienes suficiente oro, sigue recolectando");

                    }

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[22][30]) {
                    if (totalORO >= 55) {
                        System.out.println("HAS GANADO !!!! ");
                        gameOver = false;
                        cantPartidasGanadas++;
                    } else {
                        System.out.println("No tienes suficiente oro, sigue recolectando");

                    }

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }
                if (matriz[filaJ(matriz)][columasJ(matriz)] == main.matriz[30][14]) {
                    if (totalORO >= 43) {
                        System.out.println("HAS GANADO !!!! ");
                        gameOver = false;
                        cantPartidasGanadas++;
                    } else {
                        System.out.println("No tienes suficiente oro, sigue recolectando");

                    }

                } else {
                    System.out.println("NO ES UNA CASILLA DE SALIDA");
                    turnoJ = false;
                    break;
                }

//                
//                
//                
            } else if (comando.equalsIgnoreCase("ORO")) {
                vidas = 3;
                System.out.println("Total de oro obtenido: " + totalORO);
                System.out.println("enter para continuar");
                turnoJ = false;
                sc1.nextLine();

// 
//                
            } else if (comando.equalsIgnoreCase("MIRAR")) {
                vidas = 3;
                if (filaJ(matriz) == 2 && columasJ(matriz) == 2) {
                    System.out.println(" ");
                    imprimirMatriz5x5_1(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasJ(matriz) > 2 && columasJ(matriz) < 29 && filaJ(matriz) == 2) {
                    System.out.println(" ");
                    imprimirMatriz5x5_2(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasJ(matriz) == 2 && filaJ(matriz) > 2 && filaJ(matriz) < 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5_3(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (filaJ(matriz) == 29 && columasJ(matriz) == 2) {
                    System.out.println(" ");
                    imprimirMatriz5x5_4(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasJ(matriz) > 2 && columasJ(matriz) < 29 && filaJ(matriz) == 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5_5(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasJ(matriz) == 29 && filaJ(matriz) == 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5_6(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasJ(matriz) == 29 && filaJ(matriz) == 2) {
                    System.out.println(" ");
                    imprimirMatriz5x5_7(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasJ(matriz) == 29 && filaJ(matriz) > 2 && filaJ(matriz) < 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5_8(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (filaJ(matriz) > 2 && filaJ(matriz) < 29 && columasJ(matriz) > 2 && columasJ(matriz) < 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5(matriz, filaJ(matriz), columasJ(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                }

            } else {
                System.out.println("Comando inexistente");
                vidas--;
                turnoJ = true;
                if (vidas == 0) {
                    System.out.println("\nPARTIDAD PERDIDA!!! ingreso 3 comandos inexistentes");
                    gameOver = false;
                    turnoJ = false;
                    turnoB = false;
                    cantPartidas++;
                }
            }

        } while (turnoJ);
        
//verificamos si bot captura a jugador
        if (matriz[arreglo[0]][arreglo[1]] == 'B') {
            gameOver = false;
            turnoJ = false;
            turnoB = false;
            cantAtrapado++;
            cantPartidas++;
        }

    }

    public static void imprimiMatriz(char[][] matriz) {
        for (int i = 0; i < mapaPorDefecto().length; i++) {
            for (int j = 0; j < mapaPorDefecto().length; j++) {
                System.out.print(matriz[i][j] + " ");

            }
            System.out.println(" ");
        }
    }

//imprimir matrices 5x5 segun posicion de jugador o bot 
    public static void imprimirMatriz5x5(char[][] matriz, int fila, int colum) {
        for (int i = fila - 2; i < (fila + 3); i++) {
            for (int j = colum - 2; j < (colum + 3); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void imprimirMatriz5x5_1(char[][] matriz, int fila, int colum) {
        for (int i = fila - 1; i < (fila + 4); i++) {
            for (int j = colum - 1; j < (colum + 4); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void imprimirMatriz5x5_2(char[][] matriz, int fila, int colum) {
        for (int i = fila - 1; i < (fila + 4); i++) {
            for (int j = colum - 2; j < (colum + 3); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void imprimirMatriz5x5_3(char[][] matriz, int fila, int colum) {
        for (int i = fila - 2; i < (fila + 3); i++) {
            for (int j = colum - 1; j < (colum + 4); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void imprimirMatriz5x5_4(char[][] matriz, int fila, int colum) {
        for (int i = fila - 4; i < (fila + 1); i++) {
            for (int j = colum - 1; j < (colum + 4); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void imprimirMatriz5x5_5(char[][] matriz, int fila, int colum) {
        for (int i = fila - 4; i < (fila + 1); i++) {
            for (int j = colum - 2; j < (colum + 3); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void imprimirMatriz5x5_6(char[][] matriz, int fila, int colum) {
        for (int i = fila - 4; i < (fila + 1); i++) {
            for (int j = colum - 4; j < (colum + 1); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void imprimirMatriz5x5_7(char[][] matriz, int fila, int colum) {
        for (int i = fila - 1; i < (fila + 4); i++) {
            for (int j = colum - 4; j < (colum + 1); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void imprimirMatriz5x5_8(char[][] matriz, int fila, int colum) {
        for (int i = fila - 2; i < (fila + 3); i++) {
            for (int j = colum - 4; j < (colum + 1); j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

    //metodo para obtener la fila de la posicion de J
    public static int filaJ(char[][] matriz) {
        int fila = 0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                if (matriz[i][j] == 'J') {
                    fila = i;
                }
            }
        }
        return fila;
    }

    public static int columasJ(char[][] matriz) {
        int fila = 0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                if (matriz[i][j] == 'J') {
                    fila = j;
                }
            }
        }
        return fila;
    }

    public static int filaB(char[][] matriz) {
        int fila = 0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                if (matriz[i][j] == 'B') {
                    fila = i;
                }
            }
        }
        return fila;
    }

    public static int columasB(char[][] matriz) {
        int fila = 0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                if (matriz[i][j] == 'B') {
                    fila = j;
                }
            }
        }
        return fila;
    }
    
//    
//    

    public static void Bot(char[][] matriz, int filas, int colum) {

        do {    
            System.out.println(" ");
            System.out.println("TURNO DE BOT");
            System.out.println("DEBE INGRESAR UNICAMENTE LOS COMANDOS MOVER O MIRAR");
            String comandoBOT = sc2.next();

            if (comandoBOT.equalsIgnoreCase("MOVER")) {
                System.out.println("MOVIMIENTO DE BOT ");
                switch (direccion) {
                    case "derecha":
                        if (matriz[filas - 1][colum] != '#' && matriz[filas - 1][colum] != '|' && matriz[filas - 1][colum] != '-' && matriz[filas - 1][colum] != 'S' && matriz[filas - 1][colum] != 'G') {
                            matriz[filas - 1][colum] = 'B';
                            matriz[filas][colum] = 'O';
                            filas--;
                            direccion = "arriba";
                            turnoB = false;

                        } else {

                            if (matriz[filas][colum + 1] != '#' && matriz[filas][colum + 1] != '|' && matriz[filas][colum + 1] != '-' && matriz[filas][colum + 1] != 'S' && matriz[filas][colum + 1] != 'G') {
                                matriz[filas][colum + 1] = 'B';
                                matriz[filas][colum] = 'O';
                                colum++;

                            } else {

                                if (matriz[filas + 1][colum] != '#' && matriz[filas + 1][colum] != '|' && matriz[filas + 1][colum] != '-' && matriz[filas + 1][colum] != 'S' && matriz[filas + 1][colum] != 'G') {
                                    matriz[filas + 1][colum] = 'B';
                                    matriz[filas][colum] = 'O';
                                    filas++;
                                    direccion = "abajo";

                                } else {

                                    matriz[filas][colum - 1] = 'B';
                                    matriz[filas][colum] = 'O';
                                    colum--;
                                    direccion = "izquierda";

                                }

                            }

                        }

                        break;
                    case "arriba":

                        if (matriz[filas][colum - 1] != '#' && matriz[filas][colum - 1] != '|' && matriz[filas][colum - 1] != '-' && matriz[filas][colum - 1] != 'S' && matriz[filas][colum - 1] != 'G') {
                            matriz[filas][colum - 1] = 'B';
                            matriz[filas][colum] = 'O';
                            colum--;
                            direccion = "izquierda";
                            turnoB = false;

                        } else {

                            if (matriz[filas - 1][colum] != '#' && matriz[filas - 1][colum] != '|' && matriz[filas - 1][colum] != '-' && matriz[filas - 1][colum] != 'S' && matriz[filas - 1][colum] != 'G') {
                                matriz[filas - 1][colum] = 'B';
                                matriz[filas][colum] = 'O';
                                filas--;

                            } else {

                                if (matriz[filas][colum + 1] != '#' && matriz[filas][colum + 1] != '|' && matriz[filas][colum + 1] != '-' && matriz[filas][colum + 1] != 'S' && matriz[filas][colum + 1] != 'G') {
                                    matriz[filas][colum + 1] = 'B';
                                    matriz[filas][colum] = 'O';
                                    colum++;
                                    direccion = "derecha";

                                } else {

                                    matriz[filas + 1][colum] = 'B';
                                    matriz[filas][colum] = 'O';
                                    filas++;
                                    direccion = "abajo";

                                }

                            }

                        }

                        break;
                    case "izquierda":

                        if (matriz[filas + 1][colum] != '#' && matriz[filas + 1][colum] != '|' && matriz[filas + 1][colum] != '-' && matriz[filas + 1][colum] != 'S' && matriz[filas + 1][colum] != 'G') {
                            matriz[filas + 1][colum] = 'B';
                            matriz[filas][colum] = 'O';
                            filas++;
                            direccion = "abajo";
                            turnoB = false;

                        } else {

                            if (matriz[filas][colum - 1] != '#' && matriz[filas][colum - 1] != '|' && matriz[filas][colum - 1] != '-' && matriz[filas][colum - 1] != 'S' && matriz[filas][colum - 1] != 'G') {
                                matriz[filas][colum - 1] = 'B';
                                matriz[filas][colum] = 'O';
                                colum--;

                            } else {

                                if (matriz[filas - 1][colum] != '#' && matriz[filas - 1][colum] != '|' && matriz[filas - 1][colum] != '-' && matriz[filas - 1][colum] != 'S' && matriz[filas - 1][colum] != 'G') {
                                    matriz[filas - 1][colum] = 'B';
                                    matriz[filas][colum] = 'O';
                                    filas--;
                                    direccion = "arriba";

                                } else {
                                    matriz[filas][colum + 1] = 'B';
                                    matriz[filas][colum] = 'O';
                                    colum++;
                                    direccion = "derecha";

                                }

                            }

                        }

                        break;
                    case "abajo":

                        if (matriz[filas][colum + 1] != '#' && matriz[filas][colum + 1] != '|' && matriz[filas][colum + 1] != '-' && matriz[filas][colum + 1] != 'S' && matriz[filas][colum + 1] != 'G') {
                            matriz[filas][colum + 1] = 'B';
                            matriz[filas][colum] = 'O';
                            colum++;
                            direccion = "derecha";
                            turnoB = false;

                        } else {

                            if (matriz[filas + 1][colum] != '#' && matriz[filas + 1][colum] != '|' && matriz[filas + 1][colum] != '-' && matriz[filas + 1][colum] != 'S' && matriz[filas + 1][colum] != 'G') {
                                matriz[filas + 1][colum] = 'B';
                                matriz[filas][colum] = 'O';
                                filas++;
                            } else {

                                if (matriz[filas][colum - 1] != '#' && matriz[filas][colum - 1] != '|' && matriz[filas][colum - 1] != '-' && matriz[filas][colum - 1] != 'S' && matriz[filas][colum - 1] != 'G') {
                                    matriz[filas][colum - 1] = 'B';
                                    matriz[filas][colum] = 'O';
                                    colum--;
                                    direccion = "izquierda";
                                } else {
                                    matriz[filas - 1][colum] = 'B';
                                    matriz[filas][colum] = 'O';
                                    filas--;
                                    direccion = "arriba";

                                }

                            }

                        }

                        break;
                    default:
                        throw new AssertionError();
                }
                turnoB = false;

            } else if (comandoBOT.equalsIgnoreCase("MIRAR")) {

                if (filaB(matriz) == 2 && columasB(matriz) == 2) {
                    System.out.println(" ");
                    imprimirMatriz5x5_1(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasB(matriz) > 2 && columasB(matriz) < 29 && filaB(matriz) == 2) {
                    System.out.println(" ");
                    imprimirMatriz5x5_2(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasB(matriz) == 2 && filaB(matriz) > 2 && filaB(matriz) < 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5_3(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (filaB(matriz) == 29 && columasB(matriz) == 2) {
                    System.out.println(" ");
                    imprimirMatriz5x5_4(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasB(matriz) > 2 && columasB(matriz) < 29 && filaB(matriz) == 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5_5(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasB(matriz) == 29 && filaB(matriz) == 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5_6(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasB(matriz) == 29 && filaB(matriz) == 2) {
                    System.out.println(" ");
                    imprimirMatriz5x5_7(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (columasB(matriz) == 29 && filaB(matriz) > 2 && filaB(matriz) < 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5_8(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                } else if (filaB(matriz) > 2 && filaB(matriz) < 29 && columasB(matriz) > 2 && columasB(matriz) < 29) {
                    System.out.println(" ");
                    imprimirMatriz5x5(matriz, filaB(matriz), columasB(matriz));
                    System.out.println("enter para continuar");
                    sc1.nextLine();
                }
            }
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println("Thread Interrupted");
            }

        } while (turnoB);

        if ('B' == matriz[arreglo[0]][arreglo[1]] || matriz[arreglo[0]][arreglo[1]] == 'B') {
            System.out.println("EL BOT LO ATRAPO ! ");
            gameOver = false;
            turnoJ = false;
            turnoB = false;
            cantAtrapado++;
            cantPartidas++;
        }

    }

    static int[] arreglo = new int[2];

//obtenemos pision de J para verificar si es 
    public static int[] posJ(char[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                if (matriz[i][j] == 'J') {
                    arreglo[0] = i;
                    arreglo[1] = j;
                }
            }
        }
        return arreglo;
    }

    public static char[][] mapaPorDefecto() {

        char[][] matriz = {
            {'|', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '|'},
            {'|', '#', '#', '#', '#', '#', '#', '#', '#', 'S', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '|'},//1
            {'|', 'S', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', 'O', 'S', '|'},
            {'|', '#', '#', '#', '#', '#', '#', 'O', 'O', '#', '#', '#', 'O', '#', '#', '#', 'O', '#', 'O', 'O', '#', '#', '#', '#', '#', '#', 'O', 'O', '#', 'O', '#', '|'},
            {'|', '#', 'O', 'O', 'G', 'O', '#', 'O', '#', 'G', 'G', '#', 'O', '#', 'G', '#', 'O', '#', 'G', '#', 'O', '#', 'O', 'O', 'O', '#', '#', 'O', 'O', 'O', '#', '|'},
            {'|', '#', 'O', '#', '#', 'O', '#', 'O', 'O', 'O', 'O', '#', 'G', '#', 'O', '#', 'O', '#', '#', 'O', 'O', '#', 'O', '#', 'O', 'O', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', 'G', '#', 'O', 'O', '#', 'O', '#', '#', '#', '#', '#', '#', 'O', '#', 'O', 'O', 'O', '#', 'O', '#', 'O', '#', '#', '#', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', 'O', '#', '#', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', 'O', 'O', 'O', '#', '#', '#', '|'},
            {'|', '#', '#', 'O', 'O', 'O', '#', 'O', '#', 'O', '#', 'O', 'O', '#', 'O', 'O', '#', '#', 'O', '#', '#', '#', '#', '#', 'O', '#', 'O', '#', '#', 'G', '#', '|'},
            {'|', '#', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', '#', 'O', '#', 'O', '#', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', 'O', 'O', '#', 'O', 'O', '#', 'G', '#', '|'},
            {'|', '#', 'O', '#', '#', 'O', '#', '#', '#', 'O', '#', 'O', '#', 'O', '#', '#', 'O', '#', 'O', '#', '#', '#', 'O', '#', '#', '#', '#', 'G', '#', 'O', '#', '|'},
            {'|', '#', 'O', 'O', 'O', 'O', '#', 'O', '#', 'O', '#', 'O', '#', 'O', '#', 'O', 'O', '#', 'O', 'O', 'G', '#', 'O', 'O', 'O', 'O', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', '#', '#', 'G', 'O', 'O', 'O', 'O', 'O', '#', 'O', '#', 'O', '#', '#', 'O', '#', '#', '#', '#', '#', 'O', '#', 'O', '#', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', 'O', 'O', '#', 'O', 'O', '#', '#', '#', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', '#', 'O', '#', '#', 'O', '#', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', '#', 'O', '#', '#', 'O', '#', 'O', 'O', '#', 'O', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', 'O', 'O', '#', 'O', 'O', '#', 'O', '#', '#', 'O', '#', 'G', '#', 'O', '#', '#', 'O', 'O', '#', 'O', 'O', '#', 'O', 'O', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', '#', 'O', '#', '#', 'O', 'O', 'O', 'G', '#', 'O', '#', '#', '#', 'O', '#', 'O', 'O', 'O', 'O', 'O', '#', 'O', 'O', '#', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', '#', 'O', '#', 'O', 'O', '#', 'O', '#', '#', 'O', 'O', 'O', 'O', 'O', '#', 'O', '#', '#', '#', '#', '#', 'O', '#', 'O', '#', 'G', '#', 'O', '#', '|'},
            {'|', '#', 'O', 'O', 'O', 'O', '#', '#', 'O', 'O', '#', 'O', '#', 'O', '#', 'O', 'O', 'O', '#', 'G', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '#', '#', 'O', '#', '|'},
            {'|', '#', 'G', '#', 'O', '#', 'O', 'O', 'O', 'O', '#', 'O', 'O', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', 'O', 'O', 'O', 'O', '#', '|'},
            {'|', '#', 'G', '#', 'O', 'O', 'O', '#', '#', 'O', 'O', 'O', 'O', 'O', 'G', 'O', 'O', 'O', 'G', 'O', 'O', 'O', 'G', 'O', 'O', '#', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', 'O', '#', '#', '#', '#', '#', 'O', 'O', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', 'O', 'O', '#', 'O', '#', '#', '#', '|'},
            {'|', '#', 'O', '#', 'O', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', 'S', '|'},
            {'|', '#', 'O', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', 'O', '#', '#', '#', '#', '#', '#', 'O', '#', '#', '#', 'O', 'O', 'O', 'O', '#', 'O', '#', '#', '#', '|'},
            {'|', '#', 'O', '#', '#', '#', 'O', '#', 'O', '#', 'O', 'O', '#', 'G', 'O', 'O', 'O', '#', 'O', 'O', 'O', '#', 'O', '#', '#', '#', '#', 'O', '#', 'O', '#', '|'},
            {'|', '#', 'O', '#', 'O', 'O', 'O', '#', 'O', 'G', '#', 'O', '#', '#', '#', '#', 'O', '#', '#', '#', 'O', '#', 'O', 'O', 'O', 'O', '#', 'O', 'O', 'O', '#', '|'},
            {'|', '#', 'O', '#', '#', '#', 'O', '#', '#', '#', '#', 'O', '#', 'O', '#', 'O', 'O', '#', 'G', '#', 'O', '#', '#', '#', 'O', '#', 'G', '#', '#', 'O', '#', '|'},
            {'|', '#', 'O', '#', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', '#', 'O', 'O', 'O', 'O', 'O', '#', 'O', '#', 'O', 'O', '#', '|'},
            {'|', '#', 'O', '#', '#', '#', '#', '#', '#', '#', '#', '#', 'O', '#', 'O', '#', '#', '#', 'O', '#', 'O', '#', '#', '#', '#', '#', 'O', 'O', 'O', '#', '#', '|'},
            {'|', '#', 'O', 'O', 'O', 'O', 'O', 'G', 'O', 'O', 'O', 'O', 'O', '#', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '#', 'O', 'G', '#', '|'},
            {'|', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', 'S', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '|'},
            {'|', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '|'}};

        return matriz;

    }

}
